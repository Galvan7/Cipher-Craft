int a;
int b[100];
int c=3;
char d[100] = "kjbk";
char e[] ="jljlj";
int f[10]={0};
int g,h=3,i;
int myfunc()
{

}