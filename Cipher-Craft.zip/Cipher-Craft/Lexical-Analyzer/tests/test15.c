#include <stdio.h>
int main()
{
	i = 10;

}
