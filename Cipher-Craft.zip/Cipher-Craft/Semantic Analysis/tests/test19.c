#include<stdio.h>

int myfunc(float c, float d)
{

}

void main()
{
	float a,e;
	float b;
	myfunc(e, b);
}