#include<stdio.h>

int myfunc(int b)
{
    int x;
    return x;
}


void main()
{
    int n,i;
    char ch;//Character Datatype
    int x;
    int a[10];
    for (i=0;i<10;i++){
        if(i<10){
            int x;
            while(x<10){
                x++;
            }
        }

    }
   x=3;
    
}

