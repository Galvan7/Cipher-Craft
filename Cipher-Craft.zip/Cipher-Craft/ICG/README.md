# Intermediate Code Generation

## To run all tests
- Make sure all the tests are in `tests` directory with names as `test1.c`, `test2.c` etc.
- `./run.sh`