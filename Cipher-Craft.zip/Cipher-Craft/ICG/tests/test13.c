#include<stdio.h>

void main()
{
    int i,n;

    myfunc(i);
    
}