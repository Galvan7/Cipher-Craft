#include<stdio.h>

int main()
{
	int a = 2;
	printf("%d",a);
	a++;
	int b = 4;
	int c = 3; 
	
	//int b = 8;
	//int c = 3;
	a--;
}
