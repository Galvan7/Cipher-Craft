#include <stdio.h>

void main()
{
	int a;
	a = 0;
}
