#include <stdio.h>

void main()
{
	int i,n;

	
		do
		{
			printf("hi");
		}while(i<n);
}